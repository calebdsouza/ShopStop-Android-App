package com.b07.storeapplication.View;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.b07.storeapplication.R;

public class ItemBlockViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_view_item_card_view);
    }
}
