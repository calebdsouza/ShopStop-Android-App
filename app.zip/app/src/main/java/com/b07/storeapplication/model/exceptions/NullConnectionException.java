package com.b07.storeapplication.model.exceptions;

public class NullConnectionException extends Exception {

}
