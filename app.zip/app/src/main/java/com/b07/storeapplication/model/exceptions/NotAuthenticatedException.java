package com.b07.storeapplication.model.exceptions;

/**
 * Exception to be thrown when employee is not authenticated.
 */
public class NotAuthenticatedException extends Exception {

}
