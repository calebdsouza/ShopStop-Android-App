package com.b07.storeapplication.model.exceptions;

/**
 * Exception to be thrown when a User cannot be created.
 */
public class CreateUserException extends Exception {

}
