package com.b07.storeapplication.View;

/**
 * Created by cd on 2017-12-02.
 */

public interface AdminViewGetIdDialogListener {

    void applyGivenId(String id);
}
