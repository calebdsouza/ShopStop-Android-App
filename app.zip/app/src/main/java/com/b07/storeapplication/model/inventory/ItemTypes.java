package com.b07.storeapplication.model.inventory;

public enum ItemTypes {
    FISHING_ROD,
    HOCKEY_STICK,
    SKATES,
    RUNNING_SHOES,
    PROTEIN_BAR,
}
