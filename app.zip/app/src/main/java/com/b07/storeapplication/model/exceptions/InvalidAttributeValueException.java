package com.b07.storeapplication.model.exceptions;

public class InvalidAttributeValueException extends Exception {

    /**
     * serialID for insert exceptions.
     */
    private static final long serialVersionUID = -8965194369780397563L;

}
