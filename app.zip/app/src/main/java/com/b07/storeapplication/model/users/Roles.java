package com.b07.storeapplication.model.users;

public enum Roles {
    ADMIN,
    EMPLOYEE,
    CUSTOMER,
}
