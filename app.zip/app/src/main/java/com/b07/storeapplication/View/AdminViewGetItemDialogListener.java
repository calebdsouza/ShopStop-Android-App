package com.b07.storeapplication.View;

/**
 * Created by cd on 2017-12-03.
 */

public interface AdminViewGetItemDialogListener {
    void applyItemInfo(String itemName, String itemPrice);
}
